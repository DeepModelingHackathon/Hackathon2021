/*******************************************************************************/
/
/ This is the examples of ABACUS program.
/
/*******************************************************************************/

This example show how to calculate the bands structures of silicon (diamond).

Steps:
(1) ./step1.sh
(2) ./step2.sh

Finish! Then you can see BANDS_1.dat in OUT.ABACUS. Plot it!

Note:
1)If the "out_band" is used, the BANDS_1.dat will appear in the directory.
2)Learn the "Gamma" and "Line" mode of "KPOINTS".
3)The charge density needed to be output in scf calculations and be read
in non-self consistent calculations.

