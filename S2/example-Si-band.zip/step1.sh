#!/bin/bash

ABACUS=/github/abacus-develop/bin/ABACUS.mpi
cpus=4
materials=Si2_diamond

echo "Setup INPUT file for self-consistent calculations of $materials."
cat > INPUT << EOF
INPUT_PARAMETERS
#Parameters	(General)
pseudo_dir          		./
calculation			scf
ntype		  	    	1	
nbands		  		8
#Parameters (Methos)
basis_type			pw
symmetry			0	
#Parameters (Accuracy)
ecutwfc				50
dr2				1.0e-7	// about iteration

nstep				1
#force_thr_ev			1.0e-3
#Parameters (File)
out_charge			1
EOF

cat > KPT << EOF
K_POINTS
0
Gamma
4 4 4 0 0 0
EOF

mpirun -np $cpus $ABACUS >scf.txt
echo "scf done."

rm KPT
rm INPUT

#../RunTest 4
